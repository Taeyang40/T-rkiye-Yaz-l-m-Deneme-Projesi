from flask import Flask, render_template, redirect,url_for, session,flash,request
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField,SubmitField ,TextAreaField
from wtforms.validators import DataRequired, Email, ValidationError
import bcrypt
from flask_mysqldb  import MySQL


app = Flask(__name__)

# MySQL configuration
app.config['MYSQL_HOST'] = 'localhost'  
app.config['MYSQL_USER'] = 'root'  
app.coanfig['MYSQL_PASSWORD'] = 'denemeşifresi'  
app.config['MYSQL_DB'] = 'mydatabase'  
app.secret_key = 'denemeşifresi'

mysql = MySQL(app)

class RegisterForm(FlaskForm):
    name = StringField("İsim",validators=[DataRequired()])
    email = StringField("Email",validators=[DataRequired(),Email()])
    password = PasswordField("Şifre",validators=[DataRequired()])
    submit = SubmitField("Oluştur")


class LoginForm(FlaskForm):
    email = StringField("Email",validators=[DataRequired(),Email()])
    password = PasswordField("Şifre",validators=[DataRequired()])
    submit = SubmitField("Giriş Yap")


class OfferForm(FlaskForm):  
    title = StringField('Başlık', validators=[DataRequired()])
    description = TextAreaField('Açıklama', validators=[DataRequired()])
    submit = SubmitField('Teklif Oluştur')

class ItemForm(FlaskForm):
    title = StringField('Başlık', validators=[DataRequired()])
    description = TextAreaField('Açıklama', validators=[DataRequired()])
    submit = SubmitField('Kalemi Oluştur')


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register',methods=['GET','POST'])
def register():
    form =RegisterForm()
    if form.validate_on_submit():
        name = form.name.data
        email = form.email.data
        password = form.password.data

        hashed_password = bcrypt.hashpw(password.encode('utf-8'),bcrypt.gensalt())

        cursor = mysql.connection.cursor()
        cursor.execute("INSERT INTO users (name, email, password) VALUES (%s, %s, %s)", (name, email, hashed_password))
        mysql.connection.commit()
        cursor.close()

        return redirect(url_for('login'))

    return render_template('register.html',form=form )

@app.route('/login', methods=['GET','POST'])
def login():
    form =LoginForm()
    if form.validate_on_submit():
        email = form.email.data
        password = form.password.data

        cursor = mysql.connection.cursor()
        cursor.execute("SELECT * FROM users WHERE email=%s", (email,))

        user = cursor.fetchone()
        
        cursor.close()
        if user and bcrypt.checkpw(password.encode('utf-8'), user[3].encode('utf-8')):
            session['user_id']= user[0]
            return redirect(url_for('dashboard'))
        else:
            flash("Giriş başarısız. Lütfen email ve şifresinizi kontrol ediniz.")
            return redirect(url_for('login'))

    return render_template('login.html',form=form )


@app.route('/dashboard')
def dashboard():
    if 'user_id' in session:
        user_id=session['user_id']

        cursor = mysql.connection.cursor()
        cursor.execute("SELECT * FROM users where id=%s", (user_id,))

        user=cursor.fetchone()
        cursor.close()

        if user:
            return render_template('dashboard.html',user=user)
    
    return redirect(url_for('login'))

@app.route('/offer_list')
def offer_list():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    cursor = mysql.connection.cursor()
    cursor.execute("SELECT * FROM offers WHERE user_id = %s", (session['user_id'],))
    offers = cursor.fetchall()
    cursor.close()

    return render_template('offer_list.html', offers=offers)


@app.route('/offers', methods=['GET', 'POST'])
def offers():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    form = OfferForm()

    if form.validate_on_submit():
        title = form.title.data
        description = form.description.data
        user_id = session['user_id']

        
        cursor = mysql.connection.cursor()
        cursor.execute("INSERT INTO offers (title, description, user_id) VALUES (%s, %s, %s)", (title, description, user_id))
        mysql.connection.commit()
        cursor.close()

        return redirect(url_for('dashboard'))

    return render_template('offers.html', form=form)

@app.route('/items')
def items():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT * FROM items WHERE user_id = %s", (session['user_id'],))
    items = cursor.fetchall()
    cursor.close()

    return render_template('items.html', items=items)

@app.route('/delete_item/<int:item_id>', methods=['POST'])
def delete_item(item_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    cursor = mysql.connection.cursor()
    cursor.execute("DELETE FROM items WHERE id = %s AND user_id = %s", (item_id, session['user_id']))
    mysql.connection.commit()
    cursor.close()

    return redirect(url_for('items'))



@app.route('/new_item', methods=['GET', 'POST'])
def new_item():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    form = ItemForm()

    if form.validate_on_submit():
        title = form.title.data
        description = form.description.data
        user_id = session['user_id']

        cursor = mysql.connection.cursor()
        
        cursor.execute("INSERT INTO items (title, description, user_id) VALUES (%s, %s, %s)", (title, description, user_id))
        mysql.connection.commit()
        cursor.close()

        return redirect(url_for('items'))

    return render_template('new_item.html', form=form)



@app.route('/logout')
def logout():
    
    session.pop('user_id', None)  
    flash('Başarıyla çıkış yaptınız!', 'success') 
    return redirect(url_for('index'))  




if __name__ == '__main__':
    app.run(debug=True)